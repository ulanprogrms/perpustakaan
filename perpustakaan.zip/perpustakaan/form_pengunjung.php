<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku</title>
    <link rel="stylesheet" href="styless.css">
</head>
<?php
include 'connection.php';

$conn = get_connection();

// Query untuk mengambil data pengunjung
$sql = "SELECT * FROM pengunjung";
$result = $conn->query($sql);

echo "<h1>DAFTAR PENGUNJUNG</h1>";

echo "<table border='1'>
<tr>
    <th>ID</th>
    <th>Nama</th>
    <th>Alamat</th>
    <th>No. HP</th>
    <th>Actions</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['ID']}</td>
        <td>{$row['nama']}</td>
        <td>{$row['alamat']}</td>
        <td>{$row['no_hp']}</td>
        <td>
            <a href='edit_pengunjung.php?id={$row['ID']}'>Edit</a>
            <a href='delete_pengunjung.php?id={$row['ID']}' onClick=\"return confirm('Anda yakin ingin menghapus?')\">Delete</a>
        </td>
    </tr>";
}
echo "</table>";

$conn->close();
?>

<!-- Tombol untuk menuju ke form tambah pengunjung -->
<button onclick="location.href='form_tambah_pengunjung.html'">Tambah Pengunjung</button>
<!-- Tombol Kembali ke Menu Utama -->
<br><br>
<button onclick="location.href='menu.html'">Kembali ke Menu Utama</button>
