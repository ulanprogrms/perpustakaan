<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku</title>
    <link rel="stylesheet" href="styless.css">
</head>
<?php
include 'connection.php';

// Mendapatkan ID dari query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$conn = get_connection();

// Mengambil data buku yang akan diedit
$sql = "SELECT * FROM buku WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($result->num_rows > 0) {
?>
    <form action="update_buku.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <p>
            <label for="judul">Judul Buku:</label>
            <input type="text" name="judul" id="judul" value="<?php echo $row['judul']; ?>">
        </p>
        <p>
            <label for="penulis">Penulis:</label>
            <input type="text" name="penulis" id="penulis" value="<?php echo $row['penulis']; ?>">
        </p>
        <p>
            <label for="penerbit">Penerbit:</label>
            <input type="text" name="penerbit" id="penerbit" value="<?php echo $row['penerbit']; ?>">
        </p>
        <p>
            <label for="tahun_terbit">Tahun Terbit:</label>
            <input type="number" name="tahun_terbit" id="tahun_terbit" value="<?php echo $row['tahun_terbit']; ?>"> 
        </p>
        <input type="submit" value="Update">
    </form>
<?php
} else {
    echo "No results!";
}

$conn->close();
?>
