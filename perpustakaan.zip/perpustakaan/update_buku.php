<?php
include 'connection.php';

// Mendapatkan data dari form
$id = $_POST['id'];
$judul = $_POST['judul'];
$penulis = $_POST['penulis'];
$penerbit = $_POST['penerbit'];
$tahun_terbit = $_POST['tahun_terbit'];

$conn = get_connection();

// SQL untuk update data buku
$sql = "UPDATE buku SET judul = ?, penulis = ?, penerbit = ?, tahun_terbit = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $judul, $penulis, $penerbit, $tahun_terbit, $id);

if ($stmt->execute()) {
    header("Location: daftar_buku.php");
} else {
    echo "Error updating record: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
