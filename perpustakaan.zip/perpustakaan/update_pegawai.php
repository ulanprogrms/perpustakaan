<?php
include 'connection.php';

// Mendapatkan data dari form
$ID = $_POST['ID'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];
$pangkat = $_POST['pangkat'];

$conn = get_connection();

// SQL untuk update data pegawai
$sql = "UPDATE pegawai SET nama = ?, alamat = ?, `no.hp` = ?, pangkat = ? WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $nama, $alamat, $no_hp, $pangkat, $ID); // Ubah tipe data untuk pangkat menjadi "s"

if ($stmt->execute()) {
    // Jika berhasil diupdate, redirect kembali ke halaman daftar pegawai
    header("Location: daftar_pegawai.php");
    exit(); // Pastikan untuk keluar dari skrip setelah redirect
} else {
    // Jika terjadi kesalahan, tampilkan pesan kesalahan
    echo "Error updating record: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
