<?php
include 'connection.php';

// Mendapatkan data dari form
$ID = $_POST['ID'];
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];

$conn = get_connection();

// SQL untuk update data pengunjung
$sql = "UPDATE pengunjung SET nama = ?, alamat = ?, no_hp = ? WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $nama, $alamat, $no_hp, $ID);

if ($stmt->execute()) {
    // Jika berhasil diupdate, redirect kembali ke halaman daftar pengunjung
    header("Location: form_pengunjung.php");
    exit(); // Pastikan untuk keluar dari skrip setelah redirect
} else {
    // Jika terjadi kesalahan, tampilkan pesan kesalahan
    echo "Error updating record: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
