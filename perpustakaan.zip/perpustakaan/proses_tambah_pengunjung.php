<?php
include 'connection.php';

// Ambil data yang dikirimkan melalui form
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$no_hp = $_POST['no_hp'];

// Buat koneksi ke database
$conn = get_connection();

// Query untuk memasukkan data pengunjung ke dalam tabel
$sql = "INSERT INTO pengunjung (nama, alamat, no_hp) VALUES ('$nama', '$alamat', '$no_hp')";

if ($conn->query($sql) === TRUE) {
    echo "Data pengunjung berhasil ditambahkan.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi database
$conn->close();
?>

<!-- Tombol Kembali ke Menu Utama -->
<br><br>
<button onclick="location.href='menu.html'">Kembali ke Menu Utama</button>
