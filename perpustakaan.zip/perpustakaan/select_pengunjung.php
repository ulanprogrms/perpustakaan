<?php
include 'connection.php';

$conn = get_connection();

// Query untuk memilih semua data dari tabel pengunjung
$sql = "SELECT id, nama, alamat, no_hp FROM pengunjung";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nama: " . $row["nama"] . " - Alamat: " . $row["alamat"] . " - No. HP: " . $row["no_hp"] . "<br>";
    }
} else {
    echo "Tidak ada data";
}

$conn->close();
?>
