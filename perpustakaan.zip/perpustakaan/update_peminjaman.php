<?php
include 'connection.php';

// Mendapatkan data dari form
$id = $_POST['id'];
$nama_buku = $_POST['nama_buku'];
$nama_pengunjung = $_POST['nama_pengunjung'];
$tanggal_peminjaman = $_POST['tanggal_peminjaman'];

$conn = get_connection();

// SQL untuk update data peminjaman
$sql = "UPDATE peminjaman SET nama_buku = ?, nama_pengunjung = ?, tanggal_peminjaman = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sssi", $nama_buku, $nama_pengunjung, $tanggal_peminjaman, $id);

if ($stmt->execute()) {
    // Jika berhasil diupdate, redirect kembali ke halaman daftar peminjaman
    header("Location: form_peminjaman.php");
    exit(); // Pastikan untuk keluar dari skrip setelah redirect
} else {
    // Jika terjadi kesalahan, tampilkan pesan kesalahan
    echo "Error updating record: " . $conn->error;
}

$stmt->close();
$conn->close();
?>
