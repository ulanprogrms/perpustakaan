<?php
include 'connection.php';

$conn = get_connection();

// Query untuk memilih semua data dari tabel buku
$sql = "SELECT ID, judul, penulis, penerbit, tahun_terbit FROM buku";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID : " . $row["ID"] . " - Judul: " . $row["judul"] . " - penulis: " . $row["penulis"] . " - penerbit: " . $row["penerbit"] . " - tahun terbit: " . $row["tahun_terbit"] . "<br>";
    }
} else {
    echo "Tidak ada data";
}

$conn->close();
?>
