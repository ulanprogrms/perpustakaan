<?php
include 'connection.php';

$conn = get_connection();

// Query untuk memilih semua data dari tabel peminjaman
$sql = "SELECT id, nama_buku, nama_pengunjung, tanggal_peminjaman FROM peminjaman";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nama Buku: " . $row["nama_buku"] . " - Nama Pengunjung: " . $row["nama_pengunjung"] . " - Tanggal Peminjaman: " . $row["tanggal_peminjaman"] . "<br>";
    }
} else {
    echo "Tidak ada data";
}

$conn->close();
?>
