<?php
include 'connection.php';

// Mendapatkan ID peminjaman dari query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$conn = get_connection();

// Mengambil data peminjaman yang akan diedit
$sql = "SELECT * FROM peminjaman WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($result->num_rows > 0) {
?>
    <h1>Edit Peminjaman</h1>
    <form action="update_peminjaman.php" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
        <p>
            <label for="nama_buku">Nama Buku:</label>
            <input type="text" name="nama_buku" id="nama_buku" value="<?php echo $row['nama_buku']; ?>">
        </p>
        <p>
            <label for="nama_pengunjung">Nama Pengunjung:</label>
            <input type="text" name="nama_pengunjung" id="nama_pengunjung" value="<?php echo $row['nama_pengunjung']; ?>">
        </p>
        <p>
            <label for="tanggal_peminjaman">Tanggal Peminjaman:</label>
            <input type="date" name="tanggal_peminjaman" id="tanggal_peminjaman" value="<?php echo $row['tanggal_peminjaman']; ?>"> 
        </p>
        <input type="submit" value="Update">
    </form>
<?php
} else {
    echo "Peminjaman tidak ditemukan!";
}

$stmt->close();
$conn->close();
?>
