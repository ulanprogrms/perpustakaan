<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku</title>
    <link rel="stylesheet" href="stylesss.css">
</head>
<?php
include 'connection.php';

// Ambil data yang dikirimkan melalui form
$nama_buku = $_POST['nama_buku'];
$nama_pengunjung = $_POST['nama_pengunjung'];
$tanggal_peminjaman = $_POST['tanggal_peminjaman'];

// Buat koneksi ke database
$conn = get_connection();

// Query untuk memasukkan data peminjaman ke dalam tabel
$sql = "INSERT INTO peminjaman (nama_buku, nama_pengunjung, tanggal_peminjaman) 
        VALUES ('$nama_buku', '$nama_pengunjung', '$tanggal_peminjaman')";

if ($conn->query($sql) === TRUE) {
    echo "Data peminjaman berhasil ditambahkan."; 
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Tutup koneksi database
$conn->close();
?>

<!-- Tombol Kembali ke Menu Utama -->
<br><br>
<button onclick="location.href='menu.html'">Kembali ke Menu Utama</button>
