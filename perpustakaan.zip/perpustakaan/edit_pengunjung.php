<?php
include 'connection.php';

// Mendapatkan ID pengunjung dari query string
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$conn = get_connection();

// Mengambil data pengunjung yang akan diedit
$sql = "SELECT * FROM pengunjung WHERE ID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();

if ($result->num_rows > 0) {
?>
    <h1>Edit Pengunjung</h1>
    <form action="update_pengunjung.php" method="post">
        <input type="hidden" name="ID" value="<?php echo $row['ID']; ?>">
        <p>
            <label for="nama">Nama:</label>
            <input type="text" name="nama" id="nama" value="<?php echo $row['nama']; ?>">
        </p>
        <p>
            <label for="alamat">Alamat:</label>
            <input type="text" name="alamat" id="alamat" value="<?php echo $row['alamat']; ?>">
        </p>
        <p>
            <label for="no_hp">No. HP:</label>
            <input type="text" name="no_hp" id="no_hp" value="<?php echo $row['no_hp']; ?>">
        </p>
        <input type="submit" value="Update">
    </form>
<?php
} else {
    echo "Pengunjung tidak ditemukan!";
}

$stmt->close();
$conn->close();
?>
