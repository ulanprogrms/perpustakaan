<?php
include 'connection.php';

$conn = get_connection();

// Query untuk memilih semua data dari tabel pegawai
$sql = "SELECT id, nama, pangkat, gaji FROM pegawai";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . " - Nama: " . $row["nama"] . " - Pangkat: " . $row["pangkat"] . " - Gaji: " . $row["gaji"] . "<br>";
    }
} else {
    echo "Tidak ada data";
}

$conn->close();
?>
