<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku</title>
    <link rel="stylesheet" href="styless.css">
</head>
<?php
include 'connection.php';

$conn = get_connection();

// Query untuk mengambil data peminjaman
$sql = "SELECT * FROM peminjaman";
$result = $conn->query($sql);

echo "<h1>DAFTAR PEMINJAMAN</h1>";

echo "<table border='1'>
<tr>
    <th>ID</th>
    <th>Nama Buku</th>
    <th>Nama Pengunjung</th>
    <th>Tanggal Peminjaman</th>
    <th>Actions</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['nama_buku']}</td>
        <td>{$row['nama_pengunjung']}</td>
        <td>{$row['tanggal_peminjaman']}</td>
        <td>
            <a href='edit_peminjaman.php?id={$row['id']}'>Edit</a>
            <a href='delete_peminjaman.php?id={$row['id']}'
            onClick=\"return confirm('Anda yakin ingin menghapus?')\">Delete</a>
        </td>
    </tr>";
}
echo "</table>";

$conn->close();
?>

<!-- Tombol untuk menuju ke halaman form tambah peminjaman -->
<button onclick="location.href='form_tambah_peminjaman.html'">Tambah Peminjaman</button>
<!-- Tombol Kembali ke Menu Utama -->
<br><br>
<button onclick="location.href='menu.html'">Kembali ke Menu Utama</button>
